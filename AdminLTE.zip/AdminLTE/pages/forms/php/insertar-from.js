

function agregarDatos(nombrefull,fechaNac,edad,escolaridad,promedio,municipio,certificado,foto){
    
    cadena="nombrefull="+nombrefull+
            "&fechaNac="+fechaNac+
            "&edad="+edad+
            "&escolaridad="+escolaridad+
            "&promedio="+promedio+
            "&municipio="+municipio+
            "&certificado="+certificado+
            "&foto="+foto;
    
    $.ajax({
        type: "POST",
        url: "../forms/php/insertar.php",
        data: cadena,
        succes:  function(res){
            if(res==1){
                $('#tabla').load('consultar.php');
                alerify.succes("Agregado con exito");
                alert('Agregado correctamente');
            }else{
                aletify.succes("Fallo el servidor :( ");
                alert('fallo el servidor :(');
            }
        }
    
    });
}


