<?php
include('conexion.php');
/*
$p_nom = $_POST['txtNombreFull'];
$p_fecha = $_POST['txtFechaNac'];
$p_edad = $_POST['txtEdad'];
$p_escolaridad = $_POST['txtEscolaridad'];
$p_promedio = $_POST['txtPromedio'];
$p_municipio = $_POST['txtPunicipio'];
$p_certificado = $_POST['txtCertificado'];
$p_cfoto = $_POST['txtFoto'];
*/

$p_nom = $_POST['txtNombreFull'];
$p_fecha = $_POST['txtFechaNac'];
$p_edad = $_POST['txtEdad'];
$p_escolaridad = $_POST['txtEscolaridad'];
$p_promedio = $_POST['txtPromedio'];
$p_municipio = $_POST['txtMunicipio'];
$p_certificado = $_POST['txtCertificado'];
$p_cfoto = $_POST['txtFoto'];


$con = conectarbd();

$sql = "INSERT INTO t_aspirantes (namefull, fecha_nac, edad, eschool, promedio, municipio, certificado, foto) 
                                VALUES ('$p_nom', '$p_fecha', '$p_edad', '$p_escolaridad', '$p_promedio', '$p_municipio', '$p_certificado', '$p_cfoto');";


$respuesta = mysqli_query($con,$sql);

echo 'ok';

 
?>
