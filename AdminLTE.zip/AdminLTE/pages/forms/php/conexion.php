<?php
function conectarbd(){
    $host="127.0.0.1";
    $user="root";
    $pass="";
    $databse="jaime";

    if ( !( $link = @mysqli_connect($host,$user,$pass) ) ){
        echo "<h4>Error en la conexion a la base de datos [ ".$databse." ]</h4>";
        echo "<small>Php informa el Error  [ ".$php_errormsg." ]</small>";

    }

    if( !mysqli_select_db ($link,$databse) ){
        echo "<h4>Error al seleccionar la base de datos [ ".$databse." ]</h4>";
        echo "<small>Php informa el Error  [ ".$php_errormsg." ]</small>";
    }

    

    return $link;
}

if(conectarbd()){
       echo "<h4> Se Conecto exitosamente conectaDO</h4>";
    }else{
        echo "<h4>No conectaDO</h4>";
    }

?>